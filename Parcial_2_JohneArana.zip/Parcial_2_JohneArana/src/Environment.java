public enum Environment {
    PRODUCTION,
    DEVELOPMENT,
    TESTING
}
